<?php
/**
 * BLEXR functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package BLEXR
 */

if ( ! function_exists( 'blexr_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function blexr_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on BLEXR, use a find and replace
		 * to change 'blexr' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'blexr', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'blexr' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'blexr_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'blexr_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function blexr_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'blexr_content_width', 640 );
}
add_action( 'after_setup_theme', 'blexr_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function blexr_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'blexr' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'blexr' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'blexr_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function blexr_scripts() {
	wp_enqueue_style( 'blexr-style', get_stylesheet_uri() );

	wp_enqueue_script( 'blexr-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'blexr-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}




    //Addition script and style

	wp_enqueue_style( 'additional-style-custom', get_template_directory_uri().'/assets/css/custom.min.css','1',true );

	wp_enqueue_script( 'additional-js-custom', get_template_directory_uri().'/assets/js/custom.min.js',array('jquery'),'1',true );








}
add_action( 'wp_enqueue_scripts', 'blexr_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/********************ADDITIONAL**************************/

//Calculator shortcode

function calculator() {

ob_start(); ?>

<div  class="calculator_container">

   <div class="list_holder">
    <form action="<?php echo site_url() ?>/wp-admin/admin-ajax.php" method="POST" id="filter" >

	 <div class="filter">
         
		<div class="filter_header">
		  <h2>Required Parameters</h2>
        </div>

        <div class="filter_fields">
		    <div class="region_holder">
              <label> Enter region </label>
			  <input type="text" name="region" id="region" placeholder="region..." value=""></input>	
		    </div>

		     <div class="sport_holder">
		       <label> Enter league </label>
			   <input type="text" name="sport" id="sport" placeholder="league..." value="" ></input>
		     </div>

		     <div class="market_holder">
		       <label> The market to be returned</label>
			   <input type="text" name="market" id="market" placeholder="market..." value="" ></input>
		     </div>
		</div>

	</div>


	<button class="apply_filter">Apply filter</button>
	
	<input id="butsub" type="hidden" name="action" value="myfilter">


    <div id="responsive"></div>

	</form>



	</div>
	

  <div class="my_ticket_calculator_holder">	
	<div class="my_ticket_section">
	       <h1>My Ticket</h1>
	       <div class="my_ticket_table">

	               <div class="my_ticket_filter">

	                      <div class="my_ticket_filte_search">
			                      <input id="search_ticket" type="text" value="" placeholder="Search">
                          </div>
			              <div class="my_ticket_filter_sort">
                               <span>Sort</span><span class="sign_sort">+/-</span>
                          </div>

                    </div>

	                <div class="my_ticket_table_header">
		                  <span class="my_ticket_match">Game</span>
		                  <span class="my_ticket_better">Bookmakers</span>
		                  <span class="my_ticket_odd">Odd</span>
		                  <span class="my_ticket_quote">Quote</span>
		                  <span class="my_ticket_remove">X</span>
                    </div>	
	        </div>

	</div>
	<div class="calculator_holder">
		   <h2 class="calculator_title">Calculator</h2>
		   
		 
	             
				  
				  <select name="odds_format" id="odds_format" class="odds_format menu">
					 <option>Select Odds format</option>
					 <option value="decimal" id="decimal">Decimal</option>
				     <option value="american" id="american">American</option>
				     <option value="fractal" id="fractal">Fractal</option>
				   </select>



				  
				   <form action="" method="post" class="decimal menu hidden" data-parent="#odds_format" data-target="decimal">
				   
				
				        <input id="stake" type="number" value="" placeholder="Enter Stake">
				
				        <div class="odds_holder">
				           <input class="odds" type="number" value="" placeholder="Enter Odds">
						</div>
						
						<div class="add_ods">  Add odds </div>
						
						<div class="remove_value">Clear</div>
			     
				       <div id="sum" class="payout">$ <span>0</span> </div>
				       

				
               </form>

			   <form action="" method="post" class="american menu hidden" data-parent="#odds_format" data-target="american">

				          <input id="stake_american" type="number" value="" placeholder="Enter Stake">
				
				          <div class="odds_holder_american">
				                <input class="odds_american" type="number" value="" placeholder="Enter Odds">
				          </div>
				
				         <div class="add_ods_american">  Add odds </div>
				
				         <div class="remove_value_american">Clear</div>

						 <div id="sum_american" class="payout_american">$ <span>0</span> </div>

               </form>


			   <form action="" method="post" class="fractal menu hidden" data-parent="#odds_format" data-target="fractal">
			
			
			              <input id="stake_fractal" type="number" value="" placeholder="Enter Stake">
				
				           <div class="odds_holder_fractal">

						        <div class="odds_holder_fractal_inner">
					                <input class="odds_fractal_numerator" type="number" value="" placeholder=""><span> / </span>
								    <input class="odds_fractal_denominator" type="number" value="" placeholder="">
								 </div>

				           </div>
	  
			               <div class="add_ods_fractal">  Add odds </div>
	  
			               <div class="remove_value_fractal">Clear</div>

			               <div id="sum_fractal" class="payout_fractal">$ <span>0</span> </div>
				
               </form>

	    </div>

     </div>

</div>

<?php

	return ob_get_clean();
}


add_shortcode( 'calculator', 'calculator' );


/****************************************************
 * Ajax for first form region,league,market parameter
 ****************************************************/

add_action('wp_ajax_myfilter', 'main_table_filter_function'); 
add_action('wp_ajax_nopriv_myfilter', 'main_table_filter_function');
 
function main_table_filter_function(){
		
	  $result["#table_value"]="";


	
       //Sanitize
	   $region=$_POST['region'];
	   
	   $region=sanitize_text_field($region);
	   
	   $message_region = (empty($region) ? "region," : ""); 


	   $sport=$_POST['sport'];

	   $sport=sanitize_text_field($sport);
	   
	   $message_sport = (empty($sport) ? "league," : ""); 


	   $market=$_POST['market'];

	   $market=sanitize_text_field($market);
	   
	   $message_market = (empty($market) ? "market" : ""); 


	   $error_message="";

	   if (( $message_region!="")||($message_sport!="")||($message_market!="")):

		   $error_message="<div class='error_message'>Enter correct value for:".$message_region. $message_sport .$message_market; 

		   $error_message=rtrim($error_message,",")."."."</div>";

	   endif;


	   $result["#table_value"].=$error_message;

	$curl = curl_init();

    curl_setopt_array($curl, array(
	CURLOPT_URL => "https://odds.p.rapidapi.com/v1/odds?sport=".$sport."&region=".$region."&mkt=".$market,
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_FOLLOWLOCATION => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "GET",
	CURLOPT_HTTPHEADER => array(
		"x-rapidapi-host: odds.p.rapidapi.com",
		"x-rapidapi-key: 20fba3ec95msh949b5ff57dbe056p183577jsnc0071b094792"
	   ),
    ));

     $response = curl_exec($curl);
     $err = curl_error($curl);

     curl_close($curl);

 
	  $games = json_decode( $response);     



	  $result["#table_value"].='<div class="main_table">'; 
	 
	 if (empty($games)){

		$result["#table_value"].='Empty table';

	 }else{

	      foreach($games->data as $game){

			$result["#table_value"].='<div class="table_column">'; 
	
			   $result["#table_value"].='<div class="table_column_inner_header">';

					$home_team=$game->home_team;
					
					if ($home_team!=$game->teams[0]){
						$away_team=$game->teams[0];
					}else{
						$away_team=$game->teams[1];
					}

			         $result["#table_value"].='<div class="table_column_inner_match">'.$home_team.'-'.$away_team.'</div>';

			         $result["#table_value"].='<div class="table_column_inner_sign_right"><span class="odds_text">ODDS</span><span class="odds_sign">+</span></div>';

			     $result["#table_value"].='</div>';

				 $result["#table_value"].='<div class="table_column_inner_content">';

				      $result["#table_value"].='<div class="table_column_inner_content_header"><div class="table_column_inner_content_sites">Bookmakers</div><div class="table_column_inner_content_odd"><span>1</span><span>X</span><span>2</span></div></div>';
				 
				     foreach($game->sites as $site){

						$result["#table_value"].='<div class="table_column_inner_content_header"><div class="table_column_inner_content_sites">'.$site->site_nice.'</div><div class="table_column_inner_content_odd"><span>'.$site->odds->h2h[1].'</span><span>'.$site->odds->h2h[2].'</span><span>'.$site->odds->h2h[0].'</span></div></div>';

				     }

			 	 $result["#table_value"].='</div>';

			$result["#table_value"].='</div>';

	        }

	}

	$result["#table_value"].='</div>'; 



	$result = json_encode($result);


	echo $result;

 
	die();
}